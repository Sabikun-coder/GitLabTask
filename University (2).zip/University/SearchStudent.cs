﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using University;

namespace University
{
    public partial class SearchStudent : Form
    {
        public SearchStudent()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void SearchStudent_Load(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection();
            con.ConnectionString = "server=localhost;database=university;user=root;password=001002mh;";
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "select new_admissiion.NAID as Student_Id,new_admissiion.fullname as Full_Name,new_admissiion.fname as Father_Name,new_admissiion.gender as Gender,new_admissiion.dob as Date_of_Birth,new_admissiion.mobile as Number,new_admissiion.email as Email,new_admissiion.semester as Semester,new_admissiion.prog as Program,new_admissiion.sname as College,new_admissiion.session as Session,new_admissiion.address as Address,fees.fees as Fees from new_admissiion inner join fees on new_admissiion.NAID=fees.NAID";
            MySqlDataAdapter DA = new MySqlDataAdapter(cmd);
            DataSet DS = new DataSet();
            DA.Fill(DS);
            dataGridView1.DataSource = DS.Tables[0];
        }

        private void txtSearch_Click(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection();
            con.ConnectionString = "server=localhost;database=university;user=root;password=001002mh;";
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "select * from new_admissiion where NAID='"+txtReg.Text+"'";
            MySqlDataAdapter DA = new MySqlDataAdapter(cmd);
            DataSet DS = new DataSet();
            DA.Fill(DS);
            dataGridView1.DataSource = DS.Tables[0];
        }
    }
}

﻿namespace University
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtSearch = new TextBox();
            label2 = new Label();
            dataGridView1 = new DataGridView();
            btnSeach = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Olive;
            label1.Font = new Font("Calibri", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(473, 28);
            label1.Name = "label1";
            label1.Size = new Size(171, 44);
            label1.TabIndex = 0;
            label1.Text = "University";
            label1.Click += label1_Click;
            // 
            // txtSearch
            // 
            txtSearch.BackColor = Color.LightGray;
            txtSearch.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtSearch.Location = new Point(409, 159);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(307, 37);
            txtSearch.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.PapayaWhip;
            label2.Font = new Font("Calibri", 16F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(447, 91);
            label2.Name = "label2";
            label2.Size = new Size(219, 39);
            label2.TabIndex = 2;
            label2.Text = "Search teacher ";
            label2.Click += label2_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(84, 259);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(917, 285);
            dataGridView1.TabIndex = 3;
            // 
            // btnSeach
            // 
            btnSeach.BackColor = Color.PeachPuff;
            btnSeach.Location = new Point(499, 550);
            btnSeach.Name = "btnSeach";
            btnSeach.Size = new Size(112, 34);
            btnSeach.TabIndex = 4;
            btnSeach.Text = "Search";
            btnSeach.UseVisualStyleBackColor = false;
            btnSeach.Click += btnSeach_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1087, 617);
            Controls.Add(btnSeach);
            Controls.Add(dataGridView1);
            Controls.Add(label2);
            Controls.Add(txtSearch);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtSearch;
        private Label label2;
        private DataGridView dataGridView1;
        private Button btnSeach;
    }
}